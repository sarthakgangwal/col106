/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "eppcompiler.h"

//Write your code below this line

EPPCompiler::EPPCompiler(){
    output_file = "";
    memory_size = 0;
    ofstream file(output_file); file.close();
}

EPPCompiler::EPPCompiler(string out_file,int mem_limit){
    output_file = out_file;
    memory_size = mem_limit;
    ofstream file(output_file); file.close();

    for(int i=0;i<memory_size;i++){
        least_mem_loc.push_heap(i);
    }

}

void EPPCompiler::compile(vector<vector<string>> code){
    int len = code.size();

    for(int i=0;i<len;i++){

        targ.parse(code[i]);

        ExprTreeNode* node = targ.expr_trees.back();

        if(node->left->type == "VAR"){
            int var_address = targ.symtable->search(node->left->id);
            if(var_address==-2){
                int min_free_mem = least_mem_loc.get_min();
                least_mem_loc.pop();
                targ.symtable->insert(node->left->id);
                targ.symtable->assign_address(node->left->id, min_free_mem);
            }
        }

        write_to_file(generate_targ_commands());

    }
}

void help_post(SymbolTable* symtable, ExprTreeNode* curr, vector<string> &vec){
    if(curr->right!=NULL){
        help_post(symtable, curr->right, vec);
    }
    if(curr->left!=NULL){
        help_post(symtable, curr->left, vec);
    }
    

    if(curr->type=="VAL"){
        string s = "PUSH "+std::to_string(curr->num);
        vec.push_back(s);
    }
    if(curr->type=="ADD"){
        vec.push_back("ADD");
    }
    if(curr->type=="SUB"){
        vec.push_back("SUB");
    }
    if(curr->type=="MUL"){
        vec.push_back("MUL");
    }
    if(curr->type=="DIV"){
        vec.push_back("DIV");
    }
    if(curr->type=="VAR"){
        string s = "PUSH mem["+ std::to_string(symtable->search(curr->id)) +"]";
        vec.push_back(s);
    }
}

vector<string> EPPCompiler::generate_targ_commands(){
    ExprTreeNode* node = targ.expr_trees.back();

    vector<string> ans = {};

    if(node->left->type=="VAR"){
        ExprTreeNode* curr = node->right;
        help_post(targ.symtable, curr,ans);
        int mem_adrs = targ.symtable->search(node->left->id);
        string s = "mem[" + std::to_string(mem_adrs)+"] = POP";
        ans.push_back(s);
    }

    if(node->left->type=="DEL"){
        int adrs = targ.last_deleted;
        targ.last_deleted = -1;
        least_mem_loc.push_heap(adrs);
        string s = "DEL = mem[" + std::to_string(adrs)+"]";
        ans.push_back(s);
    }

    if(node->left->type=="RET"){
        ExprTreeNode* curr = node->right;
        help_post(targ.symtable, curr,ans);
        string s = "RET = POP";
        ans.push_back(s);
    }

    return ans;
}

void EPPCompiler::write_to_file(vector<string> commands){

    string sg;
    for(int i=0;i<commands.size();i++){
        sg = sg + commands[i] + "\n";
    }
    fstream file(output_file, ios::app);
    file<<sg<<endl;
    file.clear();
}

EPPCompiler::~EPPCompiler(){
    
}
