/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "parser.h"

//Write your code below this line

Parser::Parser(){
    expr_trees = {}; symtable = new SymbolTable();
}

ExprTreeNode* myparse(ExprTreeNode* root, vector<string> v, int &idx){
    if(v[idx]=="("){
        idx++;
        root->left = new ExprTreeNode();
        root->left = myparse(root->left, v, idx);
        root->type = v[idx]; 

        if(v[idx]=="+"){root->type="ADD";}
        if(v[idx]=="-"){root->type="SUB";}
        if(v[idx]=="*"){root->type="MUL";}
        if(v[idx]=="/"){root->type="DIV";}
        if(v[idx]=="%"){root->type="MOD";}
        idx++;
        root->right = new ExprTreeNode();
        root->right = myparse(root->right, v, idx);
    }
    else if( (int(v[idx][0])>= 48 &&  int(v[idx][0]) <=57) || (v[idx].length()>1 && int(v[idx][0])==45) ){
        root->type = "VAL";
        root->num = std::stoi(v[idx]);
        idx++;
        while(idx<v.size()){
            if(v[idx]!=")"){break;}
            else{idx++;}
        }
    }
    else{
        root->type = "VAR";
        root->id = v[idx];
        idx++;
        while(idx<v.size()){
            if(v[idx]!=")"){break;}
            else{idx++;}
        }
    }

    return root;
}

void Parser::parse(vector<string> expression){
    ExprTreeNode* root = new ExprTreeNode(); root->type = ":=";
    
    root->left = new ExprTreeNode();
    if(expression[0]=="ret"){root->left->type = "RET";}
    else if(expression[0]=="del"){
        root->left->type = "DEL";
        last_deleted = symtable->search(expression[2]);
        symtable->remove(expression[2]);
    }
    else{
        root->left->type = "VAR"; root->left->id = expression[0];
    }

    int idx = 2;
    root->right = new ExprTreeNode();
    root->right = myparse(root->right, expression, idx);
    expr_trees.push_back(root);
}

void destroy(ExprTreeNode* node){
    if(node!=NULL){
        destroy(node->left);
        destroy(node->right);
        delete node; node = NULL;
    }
}

Parser::~Parser(){
    delete symtable; symtable = NULL;

    for(int i=0;i<expr_trees.size();i++){
        destroy(expr_trees[i]);
    }
}