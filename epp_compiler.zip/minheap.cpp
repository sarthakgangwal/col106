/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "minheap.h"

//Write your code below this line

MinHeap::MinHeap(){
    size = 0; root = NULL;
}

void MinHeap::push_heap(int num){
    if(size==0){
        root = new HeapNode(num); size++;
        return;
    }

    int idx = size+1;
    char arr[1000];
    int tot=0;
    int prev=idx;
    while(prev!=1){
        int nex=prev/2;
        if(2*nex==prev){
            arr[tot]='l';
        }
        else{
            arr[tot]='r';
        }
        tot++; prev=nex;
    }
    tot--;
    HeapNode* temp = root;
    HeapNode* parent;
    for(int i = tot;i>=0;i--){
        parent = temp;
        if(arr[i]=='l'){
            temp = temp->left;
        }
        else{
            temp = temp->right;
        }
    }

    temp = new HeapNode(num);
    temp->par = parent;

    if(arr[0]=='l'){
        parent->left = temp;
    }
    else{
        parent->right = temp;
    }

    HeapNode* pos = temp;

    if(pos->par==NULL){return;}

    while(pos->val < pos->par->val){
        int temp = pos->val;
        pos->val = pos->par->val; 
        pos->par->val = temp;
        pos = pos->par;
        if(pos->par==NULL){
            break;
        }
    }

    size++;
}

int MinHeap::get_min(){
    return root->val;
}

void heapifydown(HeapNode* root){
    HeapNode* mini = root;
   
    if(root->left!=NULL){
        if(root->left->val < mini->val){
            mini = root->left;
        }
    }

    if(root->right!=NULL){
        if(root->right->val < mini->val){
            mini = root->right;
        }
    }

    if(mini!=root){
        int temp = root->val;
        root->val = mini->val;
        mini->val = temp;
        heapifydown(mini);
    }

}

void MinHeap::pop(){
    if(size==1){
        delete root; root = NULL;
        size--; return;
    }

    int idx = size;
    char arr[1000];
    int tot=0;
    int prev=idx;
    while(prev!=1){
        int nex=prev/2;
        if(2*nex==prev){
            arr[tot]='l';
        }
        else{
            arr[tot]='r';
        }
        tot++; prev=nex;
    }
    tot--;
    HeapNode* temp = root;
    HeapNode* parent;
    for(int i = tot;i>=0;i--){
        parent = temp;
        if(arr[i]=='l'){
            temp = temp->left;
        }
        else{
            temp = temp->right;
        }
    }

    root->val = temp->val;
    delete temp; temp = NULL;

    if(arr[0]=='l'){
        parent->left = NULL;
    }
    else{
        parent->right = NULL;
    }

    size--;

    heapifydown(root);
}

void destr(HeapNode* node){
    if(node!=NULL){
        destr(node->left);
        destr(node->right);
        delete node; node = NULL;
    }
}

MinHeap::~MinHeap(){
    size = 0; destr(root);
}