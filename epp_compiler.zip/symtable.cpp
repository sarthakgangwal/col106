/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"

//Write your code below this line

SymbolTable::SymbolTable(){
    size=0; root=NULL;
}

int get_height(SymNode* node){
    if(node==NULL){return -1;}
    else{return node->height;}
}

void update_height(SymNode* node){
    if(node->left!=NULL){update_height(node->left);}
    if(node->right!=NULL){update_height(node->right);}

    if(node->left==NULL && node->right==NULL){
        node->height = 0;
    }
    else if(node->left==NULL){
        node->height = node->right->height+1;
    }
    else if(node->right==NULL){
        node->height = node->left->height+1;
    }
    else{
        node->height = max(node->left->height, node->right->height)+1;
    }
}

int get_bf(SymNode* node){
    return get_height(node->left)-get_height(node->right);
}

SymNode* avl_insert(SymNode* node, string k, int &x){

    if(node==NULL){
        node = new SymNode(k); 
        x=1;
        return node;
    }
    else if(node->key == k){
        return node;
    }
    else if(node->key < k){
        node->right = avl_insert(node->right, k, x); 
    }
    else if(node->key > k){
        node->left = avl_insert(node->left, k, x); 
    }
   
    update_height(node);
    int bf = get_bf(node);

    if(bf > 1 && node->left!=NULL){
        //left-left imbalance
        if(k < node->left->key){
            node = node->RightRightRotation();
        }
        //left-right imbalance
        if(k > node->left->key){
            node = node->LeftRightRotation();
        }
    }

    if(bf < -1 && node->right!=NULL){
        //right-right imbalance
        if(k > node->right->key){
            node = node->LeftLeftRotation();
        }
        //right-left imbalance
        if(k < node->right->key){
            node = node->RightLeftRotation();
        }
    }

    return node;
}

void SymbolTable::insert(string k){
    int x = 0;
    root = avl_insert(root, k, x);
    if(x==1){size++;}
}

SymNode* mini(SymNode* node){
    SymNode* curr = node;
    while(curr->left!=NULL){
        curr = curr->left;
    }
    return curr;
}

SymNode* avl_del(SymNode* node, string k, int &x){
    if(node==NULL){
        return node;
    }
    else if(k < node->key){
        node->left = avl_del(node->left, k, x); 
    }
    else if(k > node->key){
        node->right = avl_del(node->right, k, x);
    }
    else{
        if(node->left==NULL || node->right==NULL){
            SymNode* temp = node->left ? node->left : node->right;
            if(temp==NULL){
                temp = NULL; delete node; node = NULL; x=1;
            }
            else{
                temp->par = node->par;
                *node = *temp;
                delete temp; temp = NULL; x=1;
            }
        }
        else{
            SymNode* temp = mini(node->right);
            node->key = temp->key; node->address = temp->address;
            node->right = avl_del(node->right, temp->key, x);
        }
    }

    if(node==NULL){
        return node;
    }

    update_height(node);
    int bf = get_bf(node);

    if(bf>1 && get_bf(node->left)>=0){
        return node->RightRightRotation();
    }
    if(bf>1 && get_bf(node->left)<0){
        return node->LeftRightRotation();
    }
    if(bf<-1 && get_bf(node->right)<=0){
        return node->LeftLeftRotation();
    }
    if(bf<-1 && get_bf(node->right)>0){
        return node->RightLeftRotation();
    }

    return node;
}

void SymbolTable::remove(string k){
    int x = 0;
    root = avl_del(root, k, x);
    if(x==1){
        size--;
    }
}

int SymbolTable::search(string k){
    if(root==NULL){return -2;}

    SymNode* curr = root;
    while(curr->key!=k){
        if(k > curr->key){
            curr = curr->right;
        }
        else{
            curr = curr->left;
        }

        if(curr==NULL){
            break;
        }
    }
    
    if(curr==NULL){
        return -2;
    }
    return curr->address;
}

void SymbolTable::assign_address(string k,int idx){
    SymNode* curr = root;
    while(curr->key!=k){
        if(k > curr->key){
            curr = curr->right;
        }
        else{
            curr = curr->left;
        }
    }
    curr->address = idx;
}

int SymbolTable::get_size(){
    return size;
}

SymNode* SymbolTable::get_root(){
    return root;
}

void destr(SymNode* node){
    if(node!=NULL){
        destr(node->left);
        destr(node->right);
        delete node; node = NULL;
    }
}

SymbolTable::~SymbolTable(){
    destr(root); size=0;
}

