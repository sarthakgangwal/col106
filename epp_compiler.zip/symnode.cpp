/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symnode.h"

//Write your code below this line

SymNode::SymNode(){
    key=""; height=0; address=-1; par=NULL; left=NULL; right=NULL;
}

SymNode::SymNode(string k){
    key=k; height=0; address=-1; par=NULL; left=NULL; right=NULL;
}

SymNode* SymNode::LeftLeftRotation(){
    SymNode* y = this->right;
    SymNode* T2 = y->left;
    if(this->par!=NULL){
        if(this->par->left==this){
            
            this->par->left = y;
        }
        else{
            
            this->par->right = y;     
        }
    }
    
    y->par = this->par;
    this->par = y; y->left = this;
    
    if(T2!=NULL){
        T2->par = this; 
    }
    this->right = T2;  
    
    return y; 
}

SymNode* SymNode::RightRightRotation(){
    SymNode* y = this->left;
    SymNode* T3 = y->right;
    if(this->par!=NULL){
        if(this->par->left==this){
            this->par->left = y;
        }
        else{
            this->par->right = y;     
        }
    }
    y->par=this->par;
    this->par = y; y->right = this;
    if(T3!=NULL){T3->par = this;} 
    this->left = T3;

    return y;
}

SymNode* SymNode::LeftRightRotation(){
    SymNode* y = this->left;
    SymNode* x = y->right;
    
    SymNode* T2 = x->left;
    SymNode* T3 = x->right;
    
    if(this->par!=NULL){
        if(this->par->left==this){
            this->par->left = x;
        }
        else{
            this->par->right = x;     
        }
    }
  
    x->par = this->par;
    x->right = this; this->par = x;
    x->left = y; y->par = x;
    this->left = T3; if(T3!=NULL){T3->par = this;}
    y->right = T2; if(T2!=NULL){T2->par = y;}
   
    return x;
}

SymNode* SymNode::RightLeftRotation(){
    SymNode* y = this->right; 
    SymNode* x = y->left;
    SymNode* T2 = x->left;
    SymNode* T3 = x->right;
    if(this->par!=NULL){
        if(this->par->left==this){
            this->par->left = x;
        }
        else{
            this->par->right = x;     
        }
    }
    x->par = this->par;
    x->left = this; this->par = x;
    x->right = y; y->par = x;
    this->right = T2; if(T2!=NULL){T2->par = this;}
    y->left = T3; if(T3!=NULL){T3->par = y;}

    return x;
}

SymNode::~SymNode(){
    key=""; height=-1; address=-1; par=NULL; left=NULL; right=NULL;
}