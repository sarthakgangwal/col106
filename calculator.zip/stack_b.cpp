#include<iostream>
#include<stdexcept>
// #include<cmath>
#include "stack_b.h"
using namespace std;

int bfloor(float f){
    if(f - int(f) == 0){
        return int(f);
    }
    else if(f>=0){
        return int(f);
    }
    else{
        return int(f-1);
    }
}
///  I am Sarthak Gangwal 2022MT11275
Stack_B::Stack_B(){
    stk = new int[1024];
    size=0;
    capacity=1024;
}
///  I am Sarthak Gangwal 2022MT11275
Stack_B::~Stack_B(){
        delete[] stk;
}
///  I am Sarthak Gangwal 2022MT11275
void Stack_B::push(int data){
    if(size!=capacity){
        stk[size] = data;
        size++;
    }
    else{
        try{
            int* new_stk = new int[2*capacity];
            capacity = 2*capacity;
        }
        catch(const std::bad_alloc){
            cout<<"Out of Memory";
            return;
        }
        int* new_stk = new int[2*capacity];
        for(int i=0;i<size;i++){
            new_stk[i] = stk[i];
        }
        new_stk[size] = data;

        delete[] stk;

        stk = new_stk;
        size++;
        
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::pop(){
    if(size==0){
        throw runtime_error("Empty Stack");
    }
    else{
        if(size==capacity/4){
            int* temp = new int[capacity/2];
            capacity = capacity/2;
            for(int i=0;i<size;i++){
                temp[i] = stk[i];
            }
            delete[] stk;
            stk = temp;
        }

        size--;
        return stk[size];
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::get_element_from_top(int idx){
    int index = size-1-idx;
    if(index<0){
        throw runtime_error("Index out of range");
    }
    else{
        return stk[index];
    } 
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::get_element_from_bottom(int idx){
    int index = idx;
    if(index>=size){
        throw runtime_error("Index out of range");
    }
    else{
        return stk[index];
    }
}
///  I am Sarthak Gangwal 2022MT11275
void Stack_B::print_stack(bool top_or_bottom){
    if(top_or_bottom){
        for(int i=size-1;i>=0;i--){
            cout<<stk[i]<<"\n";
        }
    }
    else{
        for(int i=0;i<size;i++){
            cout<<stk[i]<<"\n";
        }
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::add(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        int temp = stk[size-1]+stk[size-2];
        size--;
        stk[size-1]=temp;
        return temp;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::subtract(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        int temp = stk[size-2]-stk[size-1];
        size--;
        stk[size-1]=temp;
        return temp;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::multiply(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        int temp = stk[size-1]*stk[size-2];
        size--;
        stk[size-1]=temp;
        return temp;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::divide(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");
    }
    else if(stk[size-1]==0){
        throw runtime_error("Divide by Zero Error");
    }
    else{
        int temp = bfloor(float(stk[size-2])/float(stk[size-1]));
        size--;
        stk[size-1]=temp;
        return temp;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int* Stack_B::get_stack(){
    return stk;
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_B::get_size(){
    return size;
}




