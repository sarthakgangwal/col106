#include<iostream>
#include "node.h"
using namespace std;
///  I am Sarthak Gangwal 2022MT11275
Node::Node(bool sentinel){
    is_sentinel = 1;
    next = nullptr;
    prev = nullptr;
    
}
///  I am Sarthak Gangwal 2022MT11275
Node::Node(int v, Node* nxt, Node* prv){
    is_sentinel=0;
    value=v;
    next = nxt;
    prev = prv;
}
///  I am Sarthak Gangwal 2022MT11275
bool Node::is_sentinel_node(){
    return is_sentinel;
}
///  I am Sarthak Gangwal 2022MT11275
int Node::get_value(){
    return value;
}
///  I am Sarthak Gangwal 2022MT11275
