#include<iostream>
#include "list.h"
// #include "node.cpp"
///  I am Sarthak Gangwal 2022MT11275
using namespace std;

List::List(){
    size=0;
    sentinel_head= new Node(true); 
    sentinel_tail= new Node(true);
    sentinel_head->next = sentinel_tail;
    sentinel_tail->prev = sentinel_head;
    sentinel_head->prev = sentinel_tail;
}
///  I am Sarthak Gangwal 2022MT11275
List::~List(){
    
    Node* temp = sentinel_head;
    while(temp != sentinel_tail){
        
        temp = temp->next;
        delete temp->prev;
    }
    ///  I am Sarthak Gangwal 2022MT11275
    delete sentinel_tail;
}
///  I am Sarthak Gangwal 2022MT11275
void List::insert(int v){

    // cout<<"inside insert"<<endl;
    Node* temp = sentinel_tail->prev;
    // cout<<"before try"<<endl;
    
    try{
        Node* to_be_inserted = new Node(v, nullptr, nullptr);
    }
    catch(const std::bad_alloc){
        cout<<"Out of Memory";
        return;
    }
    Node* to_be_inserted = new Node(v, nullptr, nullptr);
    to_be_inserted->prev = temp;
    temp->next = to_be_inserted;
    to_be_inserted->next = sentinel_tail;
    sentinel_tail->prev = to_be_inserted;
    ///  I am Sarthak Gangwal 2022MT11275
    size++;

}
///  I am Sarthak Gangwal 2022MT11275
int List::delete_tail(){
    
    Node* temp = sentinel_tail->prev;
    int val = (*temp).get_value();
    temp->prev->next = sentinel_tail;
    sentinel_tail->prev = temp->prev;
    
    temp->next = nullptr;
    temp->prev = nullptr;
    delete temp;
    temp = NULL;
    size--;
    return val;
}
///  I am Sarthak Gangwal 2022MT11275
int List::get_size(){
    return size;
    
}
///  I am Sarthak Gangwal 2022MT11275
Node* List::get_head(){
    return sentinel_head;
}


