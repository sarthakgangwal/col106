#include<iostream>
// #include<cmath>
#include<stdexcept>
#include "stack_c.h"
#include "list.h"
// #include "list.cpp"
// #include "node.cpp"
// //remove this ^ and main also
// #include "node.h"
using namespace std;
///  I am Sarthak Gangwal 2022MT11275
Node* get_tail(Node* head){
    return head->prev;
}

int mfloor(float f){
    if(f - int(f) == 0){
        return int(f);
    }
    else if(f>=0){
        return int(f);
    }
    else{
        return int(f-1);
    }
}
///  I am Sarthak Gangwal 2022MT11275
Stack_C::Stack_C(){
    stk = new List();

}
///  I am Sarthak Gangwal 2022MT11275
Stack_C::~Stack_C(){
//problem is here this is wrong
    // cout<<"destructor"<<endl;
    delete stk;
    
}
///  I am Sarthak Gangwal 2022MT11275
void Stack_C::push(int data){
    (*stk).insert(data);
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::pop(){
    
    if((*stk).get_size() == 0){
        throw runtime_error("Empty Stack");
    }
    else{
        return (*stk).delete_tail();
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::get_element_from_top(int idx){
 
    if((*stk).get_size() <= idx){
        throw runtime_error("Index out of range");
    }
    else{

        Node* temp = get_tail((*stk).get_head());
        while(idx>=0 && temp->prev->prev!=nullptr){
            temp = temp->prev;
            idx--;
        }
        return (*temp).get_value();
    }
    
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::get_element_from_bottom(int idx){
  
    if((*stk).get_size() <= idx){
        throw runtime_error("Index out of range");
    }
    else{
        Node* temp = (*stk).get_head();
        while(idx>=0 && temp->next!=nullptr){
            temp = temp->next;
            idx--;
        }

        return (*temp).get_value();
    }
}
///  I am Sarthak Gangwal 2022MT11275
void Stack_C::print_stack(bool top_or_bottom){
    
    if(!top_or_bottom){
        Node* temp = (*stk).get_head();
        while(temp->next->next!=nullptr){
            temp = temp->next;
            cout<<(*temp).get_value()<<"\n";
            
        }
    }
    else{
        Node* temp = get_tail((*stk).get_head());
        while(temp->prev->prev!=nullptr){
            temp = temp->prev;
            cout<<(*temp).get_value()<<"\n";
             
        }
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::add(){
    
    if((*stk).get_size()<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        Node* temp = get_tail((*stk).get_head());
        int ans=0;
        temp = temp->prev;
        ans+=(*temp).get_value();
        temp = temp->prev;
        ans+=(*temp).get_value();

        (*stk).delete_tail();(*stk).delete_tail();
        (*stk).insert(ans);
        return ans;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::subtract(){
    
    if((*stk).get_size()<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        Node* temp = get_tail((*stk).get_head());
        int ans=0;
        temp = temp->prev;
        ans-=(*temp).get_value();
        temp = temp->prev;
        ans+=(*temp).get_value();

        (*stk).delete_tail();(*stk).delete_tail();
        (*stk).insert(ans);
        return ans;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::multiply(){
   
    if((*stk).get_size()<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        Node* temp = get_tail((*stk).get_head());
        int ans=1;
        temp = temp->prev;
        ans*=(*temp).get_value();
        temp = temp->prev;
        ans*=(*temp).get_value();

        (*stk).delete_tail();(*stk).delete_tail();
        (*stk).insert(ans);
        return ans;
    }
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::divide(){
    
    if((*stk).get_size()<2){
        throw runtime_error("Not Enough Arguments");
    }
    else{
        Node* temp = get_tail((*stk).get_head());
        int ans=1;
        temp = temp->prev;
        temp = temp->prev;
        ans*=(*temp).get_value();
        temp = temp->next;
        if((*temp).get_value() == 0){
            throw runtime_error("Divide by Zero Error");
        }
        else{
            ans = mfloor(float(ans)/float((*temp).get_value()));

            (*stk).delete_tail();(*stk).delete_tail();
            (*stk).insert(ans);
            return ans;
        }
    }
}
///  I am Sarthak Gangwal 2022MT11275
List* Stack_C::get_stack(){
    return stk;
}
///  I am Sarthak Gangwal 2022MT11275
int Stack_C::get_size(){
    return (*stk).get_size();
}

///  I am Sarthak Gangwal 2022MT11275