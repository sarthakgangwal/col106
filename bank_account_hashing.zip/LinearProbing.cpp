#include "LinearProbing.h"
#include<iostream>

using namespace std;

void merge2(vector<int> &v, int l, int m, int r){
    int i=0, j=0, k=l;
    int n1 = m - l + 1;
    int n2 =  r - m;
    int L[n1], R[n2];
    for (int i = 0; i < n1; i++)
        L[i] = v[l + i];
    for (int j = 0; j < n2; j++)
        R[j] = v[m + 1+ j];

    while (i < n1 && j < n2){
        if(L[i] <= R[j]){
            v[k] = L[i];
            i++;
        }
        else{
            v[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1){
        v[k] = L[i];
        i++;
        k++;
    }
    while(j < n2){
        v[k] = R[j];
        j++;
        k++;
    }
}

void mergesort2(vector<int> &v, int l, int r){
    if (l < r){
        int m = l+(r-l)/2;
        mergesort2(v, l, m);
        mergesort2(v, m+1, r);
        merge2(v, l, m, r);
    }
}

void LinearProbing::createAccount(std::string id, int count) {
    // IMPLEMENT YOUR CODE HERE
    if(bankStorage1d.capacity()==0){
        Account emp; emp.id = ""; emp.balance = -1;
        bankStorage1d.resize(this->p2, emp);
        Account acc; acc.id = id; acc.balance = count;
        bankStorage1d[this->hash(id)] = acc;
        this->c2++;
    }
    
    else{
        Account acc; acc.id = id; acc.balance = count;
        bankStorage1d[this->hash(id)] = acc;
        this->c2++;
    }
}

std::vector<int> LinearProbing::getTopK(int k) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c2==0){vector<int> ans={};return ans;}
    vector<int> all;
    for(int i=0;i<bankStorage1d.size();i++){
        if(bankStorage1d[i].balance>=0){
            all.push_back(bankStorage1d[i].balance);
        }
    }
    int x=all.size();
    mergesort2(all,0,x-1);
    
    vector<int> ans;
    int j=x-1;

    while(j>=0 && j>=x-k){
        ans.push_back(all[j]);
        j--;
    }

    return ans; // Placeholder return value
}

int LinearProbing::getBalance(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c2==0){return -1;}
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p2) + i)%this->p2;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }
    if(found==false){
        return -1;
    }
    else{
        return bankStorage1d[idx].balance;
    }

    // return bal; // Placeholder return value
}

void LinearProbing::addTransaction(std::string id, int count) {
    // IMPLEMENT YOUR CODE HERE
    if(bankStorage1d.capacity()==0){
        Account emp; emp.id = ""; emp.balance = -1;
        bankStorage1d.resize(this->p2, emp);
        Account acc; acc.id = id; acc.balance = count;
        bankStorage1d[this->hash(id)] = acc;
        this->c2++;
        return;
    }

    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p2) + i)%this->p2;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }
    if(found==false){
        this->createAccount(id,count);
    }
    else{
        bankStorage1d[idx].balance +=count;
    }

}

bool LinearProbing::doesExist(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c2==0){return false;}
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p2) + i)%this->p2;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }

    return found; // Placeholder return value
}

bool LinearProbing::deleteAccount(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c2==0){return false;}
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p2) + i)%this->p2;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }
    if(found==false){
        return false;
    }
    else{
        bankStorage1d[idx].balance = -2;
        bankStorage1d[idx].id = "";
        this->c2 --;
        return true;
    }

     // Placeholder return value
}
int LinearProbing::databaseSize() {
    // IMPLEMENT YOUR CODE HERE
    return this->c2; // Placeholder return value
}

int LinearProbing::hash(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}

    int i=0,idx;
    while(true){
        idx = ( (sum % this->p2) + i)%this->p2;
        if(bankStorage1d[idx].balance <0){
            break;
        }
        if(bankStorage1d[idx].id == id){
            break;
        }
        i++;
    }
    return idx; // Placeholder return value
}

