#include "Chaining.h"
#include <iostream>


using namespace std;

void merge1(vector<int> &v, int l, int m, int r){
    int i=0, j=0, k=l;
    int n1 = m - l + 1;
    int n2 =  r - m;
    int L[n1], R[n2];
    for (int i = 0; i < n1; i++)
        L[i] = v[l + i];
    for (int j = 0; j < n2; j++)
        R[j] = v[m + 1+ j];

    while (i < n1 && j < n2){
        if(L[i] <= R[j]){
            v[k] = L[i];
            i++;
        }
        else{
            v[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1){
        v[k] = L[i];
        i++;
        k++;
    }
    while(j < n2){
        v[k] = R[j];
        j++;
        k++;
    }
}

void mergesort1(vector<int> &v, int l, int r){
    if (l < r){
        int m = l+(r-l)/2;
        mergesort1(v, l, m);
        mergesort1(v, m+1, r);
        merge1(v, l, m, r);
    }
}

void Chaining::createAccount(std::string id, int count) {
    // IMPLEMENT YOUR CODE HERE
    
    if(bankStorage2d.capacity()==0){
        bankStorage2d.resize(this->p1);
        Account acc; acc.id = id; acc.balance = count;
        bankStorage2d[this->hash(id)].push_back(acc);
        this->c1++;
    }
    
    else{
        Account acc; acc.id = id; acc.balance = count;
        bankStorage2d[hash(id)].push_back(acc);
        this->c1++;
    }
}

std::vector<int> Chaining::getTopK(int k) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c1==0){vector<int> ans = {};return ans;}
    
    vector<int> all;
    for(int i=0;i<bankStorage2d.size();i++){
        for(int j=0; j<bankStorage2d[i].size(); j++){
            all.push_back(bankStorage2d[i][j].balance);
        }
    }
    int x = all.size();
    mergesort1(all,0,x-1);


    vector<int> ans;
    int j=x-1;

    while(j>=0 && j>=x-k){
        ans.push_back(all[j]);
        j--;
    }

    return ans; // Placeholder return value
}

int Chaining::getBalance(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c1==0){return -1;}
    int bal = -1, idx = this->hash(id);
    for(int i=0;i<bankStorage2d[idx].size();i++){
        if(bankStorage2d[idx][i].id == id){
            bal = bankStorage2d[idx][i].balance;
            break;
        }
    }
    
    return bal; // Placeholder return value
}

void Chaining::addTransaction(std::string id, int count) {
    // IMPLEMENT YOUR CODE HERE
    if(bankStorage2d.capacity()==0){
        bankStorage2d.resize(this->p1);
        Account acc; acc.id = id; acc.balance = count;
        bankStorage2d[this->hash(id)].push_back(acc);
        this->c1++;
        return;
    }
    if(this->doesExist(id)==false){
        this->createAccount(id,count);
    }
    else{
        int idx = this->hash(id);
        for(int i=0;i<bankStorage2d[idx].size();i++){
            if(bankStorage2d[idx][i].id == id){
                bankStorage2d[idx][i].balance += count;
                break;
            }
        }
    }
}

bool Chaining::doesExist(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c1==0){return false;}

    int idx = this->hash(id);
    for(int i=0;i<bankStorage2d[idx].size();i++){
        if(bankStorage2d[idx][i].id == id){
            return true;
        }
    }
    return false; // Placeholder return value
}

bool Chaining::deleteAccount(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c1==0){return false;}
    if(this->doesExist(id)==false){return false;}
    int idx = hash(id),pos=0;

    for(int i=0;i<bankStorage2d[idx].size();i++){
        if(bankStorage2d[idx][i].id == id){
            pos=i;break;
        }
    }
    bankStorage2d[idx].erase(bankStorage2d[idx].begin()+pos);
    this->c1--;
    return true; // Placeholder return value
}
int Chaining::databaseSize() {
    // IMPLEMENT YOUR CODE HERE
    return this->c1; // Placeholder return value
}

int Chaining::hash(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}

    return sum% this->p1; // Placeholder return value
}

