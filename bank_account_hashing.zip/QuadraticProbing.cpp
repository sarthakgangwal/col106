#include "QuadraticProbing.h"
#include<iostream>

using namespace std;

void merge3(vector<int> &v, int l, int m, int r){
    int i=0, j=0, k=l;
    int n1 = m - l + 1;
    int n2 =  r - m;
    int L[n1], R[n2];
    for (int i = 0; i < n1; i++)
        L[i] = v[l + i];
    for (int j = 0; j < n2; j++)
        R[j] = v[m + 1+ j];

    while (i < n1 && j < n2){
        if(L[i] <= R[j]){
            v[k] = L[i];
            i++;
        }
        else{
            v[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1){
        v[k] = L[i];
        i++;
        k++;
    }
    while(j < n2){
        v[k] = R[j];
        j++;
        k++;
    }
}

void mergesort3(vector<int> &v, int l, int r){
    if (l < r){
        int m = l+(r-l)/2;
        mergesort3(v, l, m);
        mergesort3(v, m+1, r);
        merge3(v, l, m, r);
    }
}
void QuadraticProbing::createAccount(std::string id, int count) {
    // IMPLEMENT YOUR CODE HERE
    if(bankStorage1d.capacity()==0){
        Account emp; emp.id = ""; emp.balance = -1;
        bankStorage1d.resize(this->p3, emp);
        Account acc; acc.id = id; acc.balance = count;
        bankStorage1d[this->hash(id)] = acc;
        this->c3++;
    }
    
    else{
        Account acc; acc.id = id; acc.balance = count;
        bankStorage1d[this->hash(id)] = acc;
        this->c3++;
    }
}

std::vector<int> QuadraticProbing::getTopK(int k) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c3==0){vector<int> ans={};return ans;}
    vector<int> all;
    for(int i=0;i<bankStorage1d.size();i++){
        if(bankStorage1d[i].balance>=0){
            all.push_back(bankStorage1d[i].balance);
        }
    }
    int x=all.size();
    mergesort3(all,0,x-1);
    
    vector<int> ans;
    int j=x-1;

    while(j>=0 && j>=x-k){
        ans.push_back(all[j]);
        j--;
    }

    return ans; // Placeholder return value
}

int QuadraticProbing::getBalance(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c3==0){return -1;}
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p3) + i*i)%this->p3;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }
    if(found==false){
        return -1;
    }
    else{
        return bankStorage1d[idx].balance;
    }
}

void QuadraticProbing::addTransaction(std::string id, int count) {
    // IMPLEMENT YOUR CODE HERE
    if(bankStorage1d.capacity()==0){
        Account emp; emp.id = ""; emp.balance = -1;
        bankStorage1d.resize(this->p3, emp);
        Account acc; acc.id = id; acc.balance = count;
        bankStorage1d[this->hash(id)] = acc;
        this->c3++;
        return;
    }
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p3) + i*i)%this->p3;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }
    if(found==false){
        this->createAccount(id,count);
    }
    else{
        bankStorage1d[idx].balance +=count;
    }
}

bool QuadraticProbing::doesExist(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c3==0){return false;}
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p3) + i*i)%this->p3;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }

    return found; // Placeholder return value
}

bool QuadraticProbing::deleteAccount(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    if(this->c3==0){return false;}
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}
    int i=0,idx;
    bool found=false;
    while(true){
        idx = ( (sum % this->p3) + i*i)%this->p3;
        if(bankStorage1d[idx].balance == -1){
            break;
        }
        if(bankStorage1d[idx].id == id){
            found=true;
            break;
        }
        i++;
    }
    if(found==false){
        return false;
    }
    else{
        bankStorage1d[idx].balance = -2;
        bankStorage1d[idx].id = "";
        this->c3 --;
        return true;
    }
}
int QuadraticProbing::databaseSize() {
    // IMPLEMENT YOUR CODE HERE
    return this->c3; // Placeholder return value
}

int QuadraticProbing::hash(std::string id) {
    // IMPLEMENT YOUR CODE HERE
    int sum=0;
    for(int i=0;i<id.length();i++){sum+= id[i]* (i+1);}

    int i=0,idx;
    while(true){
        idx = ( (sum % this->p3) + i*i)%this->p3;
        if(bankStorage1d[idx].balance <0){
            break;
        }
        if(bankStorage1d[idx].id == id){
            break;
        }
        i++;
    }
    return idx; // Placeholder return value
}

