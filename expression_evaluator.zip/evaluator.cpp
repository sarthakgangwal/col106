/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "evaluator.h"

Evaluator::Evaluator(){
    expr_trees = {};
    symtable = new SymbolTable();
}

void del_tree(ExprTreeNode* root){
    if(root!=nullptr){
        del_tree(root->left);
        del_tree(root->right);
        delete root; root = nullptr;
    }
}

Evaluator::~Evaluator(){
    delete symtable;
    symtable = nullptr;
    for(int i=0;i<expr_trees.size();i++){
        del_tree(expr_trees[i]);
    }
    expr_trees = {};
}

ExprTreeNode* myparse(ExprTreeNode* root, vector<string> v, int &idx){
    if(v[idx]=="("){
        idx++;
        root->left = new ExprTreeNode();
        root->left = myparse(root->left, v, idx);
        root->type = v[idx]; 

        if(v[idx]=="+"){root->type="ADD";}
        if(v[idx]=="-"){root->type="SUB";}
        if(v[idx]=="*"){root->type="MUL";}
        if(v[idx]=="/"){root->type="DIV";}
        if(v[idx]=="%"){root->type="MOD";}
        idx++;
        root->right = new ExprTreeNode();
        root->right = myparse(root->right, v, idx);
    }
    else if( (int(v[idx][0])>= 48 &&  int(v[idx][0]) <=57) || (v[idx].length()>1 && int(v[idx][0])==45) ){
        root->type = "VAL";
        UnlimitedInt* one = new UnlimitedInt("1");
        UnlimitedInt* num = new UnlimitedInt(v[idx]);
        root->val = new UnlimitedRational(num,one);
        idx++;
        while(idx<v.size()){
            if(v[idx]!=")"){break;}
            else{idx++;}
        }
    }
    else{
        root->type = "VAR";
        root->id = v[idx];
        idx++;
        while(idx<v.size()){
            if(v[idx]!=")"){break;}
            else{idx++;}
        }
    }

    return root;
}

void Evaluator::parse(vector<string> code){
    ExprTreeNode* root = new ExprTreeNode(); root->type = ":=";
    root->left = new ExprTreeNode(); root->left->type = "VAR"; root->left->id = code[0];

    int idx = 2;
    root->right = new ExprTreeNode();
    root->right = myparse(root->right, code, idx);
    expr_trees.push_back(root);
}

void myeval(ExprTreeNode* root, SymbolTable* symtable){
    if(root->left){
        myeval(root->left, symtable);
    }
    if(root->right){
        myeval(root->right, symtable);
    }
    if(root->type=="VAL"){
        root->evaluated_value = new UnlimitedRational(root->val->get_p(),root->val->get_q());
    }
    if(root->type=="VAR"){
        UnlimitedRational* temp = symtable->search(root->id);
        UnlimitedInt* p = temp->get_p();UnlimitedInt* q = temp->get_q();
        UnlimitedRational* curr = new UnlimitedRational(p,q); 
        root->evaluated_value = curr;
    }
    else{
        if(root->type=="ADD"){
            root->evaluated_value = UnlimitedRational::add(root->left->evaluated_value,root->right->evaluated_value);
        }
        if(root->type=="SUB"){
            root->evaluated_value = UnlimitedRational::sub(root->left->evaluated_value,root->right->evaluated_value);
        }
        if(root->type=="MUL"){
            root->evaluated_value = UnlimitedRational::mul(root->left->evaluated_value,root->right->evaluated_value);
        }
        if(root->type=="DIV"){
            root->evaluated_value = UnlimitedRational::div(root->left->evaluated_value,root->right->evaluated_value);
        }
    }
}

void inorder(SymEntry* root){
    if(root->left){inorder(root->left);}
    if(root->right){inorder(root->right);}
}

void Evaluator::eval(){
    ExprTreeNode* root = expr_trees.back();
    ExprTreeNode* exp = root->right;
    myeval(exp,symtable);
    UnlimitedRational* sg = new UnlimitedRational(exp->evaluated_value->get_p(), exp->evaluated_value->get_q());
    symtable->insert(root->left->id,sg);
}

