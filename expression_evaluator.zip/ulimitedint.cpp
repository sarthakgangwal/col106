/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedint.h"

int UnlimitedInt::get_sign(){
    return this->sign;
}

int UnlimitedInt::get_size(){
    return this->size;
}

int* UnlimitedInt::get_array(){
    return this->unlimited_int;
}

UnlimitedInt::UnlimitedInt(){
    sign = 0; size = 1; capacity = 1; unlimited_int = new int[1]; unlimited_int[0]=0;
}

UnlimitedInt::UnlimitedInt(string s){
    if(s[0]=='0' && s.length()==1){
        sign = 0; size = 1; capacity = 1; unlimited_int = new int[1]; unlimited_int[0]=0;
    }
    else if(s[0]=='-'){
        sign = -1; size = s.length()-1; capacity = s.length()-1; unlimited_int = new int[size];
        for(int i=0;i<size; i++){
            unlimited_int[i]= int(s[i+1])-48;
        }
    }
    else{
        sign = 1; size = s.length(); capacity = s.length(); unlimited_int = new int[size];
        for(int i=0;i<size; i++){
            unlimited_int[i]= int(s[i])-48;
        }
    }
}

UnlimitedInt::UnlimitedInt(int i){
    if(i==0){
        sign = 0; size = 1; capacity = 1; unlimited_int = new int[1]; unlimited_int[0]=0;
    }
    else{
        if(i<0){
            sign = -1; i=i*(-1);
        }
        else{
            sign = 1;
        }

        size = 0;
        int x = i;
        while(x>0){
            x = x/10; size++;
        }
        capacity = size;
        unlimited_int = new int[size];
        for(int j = size-1;j>=0;j--){
            unlimited_int[j] = i%10; i = i/10;
        }
    }
}

UnlimitedInt::UnlimitedInt(int* ulimited_int, int cap, int sgn, int sz){
    size = sz; sign = sgn; unlimited_int = ulimited_int; capacity = cap;
}

UnlimitedInt::~UnlimitedInt(){
    delete[] unlimited_int;
    unlimited_int = nullptr;
    size=0;capacity=0;sign=0;
}

string UnlimitedInt::to_string(){
    string s = "";
    for(int i=0;i<size;i++){
        s = s+ std::to_string(unlimited_int[i]);
    }
    if(sign==-1){
        s = "-"+s;
    }
    return s;
}

UnlimitedInt* UnlimitedInt::add(UnlimitedInt* i1, UnlimitedInt* i2){
    if(  (i1->sign * i2->sign) == 1){
        string s1 = i1->to_string();
        string s2 = i2->to_string();
        if(i1->sign==-1){
            string s3 = "";
            for(int i=1;i<s1.length();i++){
                s3 = s3+s1[i];
            }
            s1=s3;
            string s4 = "";
            for(int i=1;i<s2.length();i++){
                s4 = s4+s2[i];
            }
            s2=s4;
        }
        
        if(s2.length() < s1.length()){
            swap(s1,s2);
        }

        string s = "";
        int carry = 0;
        int i=0;
        while(i<s1.length()){
            int x = carry + (s1[s1.length()-1-i] - '0') + (s2[s2.length()-1-i] - '0');
            if(x>9){carry=1;}
            else{carry = 0;}
            x=x%10;
            s = std::to_string(x) + s;
            i++;
        }
        while(carry!=0 || i<s2.length()){
            if(i<s2.length()){
                int x = carry + (s2[s2.length()-1-i] - '0');
                if(x>9){carry=1;}
                else{carry = 0;}
                x=x%10;
                s = std::to_string(x) + s;
                i++;
            }
            else{
                s = "1" + s;
                carry=0;
            }
        }

        UnlimitedInt* sumpointer = new UnlimitedInt(s);
        if(i1->sign==-1){
            sumpointer->sign = -1;
        }
        return sumpointer;
    }
    else if(i1->sign==0){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string());
        return p;
    }
    else if(i2->sign==0){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string());
        return p;
    }
    else if(i1->sign==1 && i2->sign==-1){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string());
        p->sign = 1;
        return sub(i1,p);
    }
    else if(i1->sign==-1 && i2->sign==1){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string());
        p->sign = 1;
        return sub(i2,p);
    }
}

UnlimitedInt* UnlimitedInt::sub(UnlimitedInt* i1, UnlimitedInt* i2){
    if(i1->sign == 1 && i2->sign == 1){
        string s1 = i1->to_string();
        string s2 = i2->to_string();

        int y=0;
        if(i1->size < i2->size){y=1;}
        else if(i1->size == i2->size){
            if(s2 > s1){y=1;}
        }

        if(y==1){swap(s1,s2);}
        string s = "";
        int carry = 0;
        int i=0;
        while(i<s2.length()){
            int x = carry + (s1[s1.length()-1-i] - '0') - (s2[s2.length()-1-i] - '0');
            if(x>=0){carry=0;}
            else{x+=10; carry = -1;}
            x = abs(x); 
            s = std::to_string(x) + s;
            i++;
        }
        while(i<s1.length()){
            int x = carry + (s1[s1.length()-1-i] - '0');
            if(x>=0){carry=0;}
            else{x+=10; carry = -1;}
            x = abs(x); 
            s = std::to_string(x) + s;
            i++;
        }

        int j=0;
        while(s[j]=='0'){j++;}
        string ss = "";
        while(j<s.length()){
            ss = ss + s[j];
            j++;
        }
        if(y==1){
            ss = "-" + ss;
        }
        if(ss==""){ss="0";}
        UnlimitedInt* sumpointer = new UnlimitedInt(ss);
        return sumpointer;
    }
    else if(i1->sign==1 && i2->sign==-1){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string());
        p->sign = 1;
        return add(i1,p);
    }
    else if(i1->sign==-1 && i2->sign==1){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string()); 
        p->sign = 1;
        UnlimitedInt* i4 = add(p,i2);
        i4->sign = -1;
        return i4;
    }
    else if(i1->sign==-1 && i2->sign==-1){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string());
        p->sign = 1;
        return add(p,i1);
    }
    else if(i1->sign==0){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string());
        p->sign = (-1)*(p->sign);
        return p;
    }
    else if(i2->sign==0){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string());
        return p;
    }
}

UnlimitedInt* UnlimitedInt::mul(UnlimitedInt* i1, UnlimitedInt* i2){
    if(i1->sign==1 && i2->sign==1){
        string s1 = i1->to_string();
        string s2 = i2->to_string();
        if(s1.length() < s2.length()){
            int d = s2.length() - s1.length();
            string s = "";
            while(d--){s = "0" + s;}
            s = s + s1;
            s1 = s;
        }
        else if(s2.length() < s1.length()){
            int d = s1.length() - s2.length();
            string s = "";
            while(d--){s = "0"+s;}
            s = s+ s2;
            s2 = s;
        }
       
        int d = s1.length(); 
        int arr[2*d] = {0};
        int x = 2*d-1;
        int y = d-1;
        while(x>=d){
            int carry = 0;
            for(int i = d-1;i>=0;i--){
                arr[x - (d-1-i)] += carry + int(s2[y]-'0')*int(s1[i]-'0');
                carry = arr[x - (d-1-i)] / 10; 
                arr[x - (d-1-i)] = arr[x - (d-1-i)] % 10;
            }
            int p = x-d;
            while(carry!=0){
                arr[p] += carry;
                carry = arr[p]/10; arr[p] = arr[p]%10;
                p--; 
            }
            x--;y--;
        }

        string s = "";
        int k = 0;
        while(arr[k]==0){k++;}
        while(k<2*d){
            s = s + std::to_string(arr[k]); k++;
        } 
        return new UnlimitedInt(s);
    }
    else if(i1->sign==0 || i2->sign==0){
        return new UnlimitedInt("0");
    }
    else if(i1->sign==-1 && i2->sign==1){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string()); p->sign = 1;
        UnlimitedInt* q = mul(p,i2); q->sign = -1;
        return q;
    }
    else if(i1->sign==-1 && i2->sign==-1){
        UnlimitedInt* a = new UnlimitedInt(i1->to_string()); a->sign=1;
        UnlimitedInt* b = new UnlimitedInt(i2->to_string()); b->sign=1;
        return mul(a,b);
    }
    else if(i1->sign==1 && i2->sign==-1){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string()); p->sign = 1;
        UnlimitedInt* q = mul(i1,p); q->sign = -1;
        return q;
    }
}

UnlimitedInt* UnlimitedInt::div(UnlimitedInt* i1, UnlimitedInt* i2){
    if(i1->sign==1 && i2->sign==1){
        if(i1->size < i2->size){
            return new UnlimitedInt("0");
        }
        else if(i1->size == i2->size){
            if(i1->to_string() < i2->to_string()){
                return new UnlimitedInt("0");
            }
        }
        string a = i1->to_string(), b = i2->to_string();
        string vec[1000] = {""};
        string w = "1";
        for(int q=0;q<1000;q++){
            vec[q] = w; w += "0";
        }
        int u=0;
        string s1 = vec[0], s2 = vec[0];
        UnlimitedInt* pobj = new UnlimitedInt(s1);
        UnlimitedInt* mg = sub(i1, mul(i2, pobj));

        while( (mg)->sign > 0){
            s2 = s1; u++; s1 = vec[u]; pobj = new UnlimitedInt(s1);
            delete mg;
            mg = sub(i1, mul(i2, pobj));
        }
        
        if((mg)->sign == 0){
            return pobj;
        }

        string s = s2; u--; 
        UnlimitedInt* psun = new UnlimitedInt(s);
        while(u>=0){
            UnlimitedInt uun = UnlimitedInt(vec[u]); UnlimitedInt* puun = &uun;
            for(int h = 0;h<10;h++){
                UnlimitedInt hun = UnlimitedInt( std::to_string(h)); UnlimitedInt* phun = &hun;
                UnlimitedInt* dh = mul(puun,phun); 
                UnlimitedInt* sg = mul(i2, add(psun, dh));
                if( sub(i1, sg)->sign < 0){
                    UnlimitedInt hun = UnlimitedInt( std::to_string(h-1)); UnlimitedInt* phun = &hun;
                    UnlimitedInt* dh = mul(puun,phun); UnlimitedInt* sg = add(psun, dh);
                    delete psun; psun = new UnlimitedInt(sg->to_string());
                    s = sg->to_string();
                    break;
                }
                else if(sub(i1, sg)->sign == 0){
                    return add(psun, dh);
                }

                if(h==9){
                    sg = add(psun,dh);
                    delete psun; psun = new UnlimitedInt(sg->to_string());
                }
            }
            u--;
        }
        return psun;
    }
    else if(i1->sign==0){
        return new UnlimitedInt("0");
    }
    else if(i1->sign==-1 && i2->sign==1){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string()); p->sign=1;
        UnlimitedInt* y = div(p,i2);
        if(UnlimitedInt::mod(p,i2)->get_sign()!=0){
            UnlimitedInt* x = UnlimitedInt::add(y,new UnlimitedInt(1));
            if(x->sign!=0){
                x->sign = -1;
            }
            return x;
        }
        else{
            if(y->sign!=0){
                y->sign = -1;
            }
            return y;
        }
    }
    else if(i1->sign==1 && i2->sign==-1){
        UnlimitedInt* p = new UnlimitedInt(i2->to_string());
        p->sign=1;
        UnlimitedInt* y = div(i1,p);
        if(UnlimitedInt::mod(i1,p)->get_sign()!=0){
            UnlimitedInt* x = UnlimitedInt::add(y,new UnlimitedInt(1));
            if(x->sign!=0){
                x->sign = -1;
            }
            return x;
        }
        else{
            if(y->sign!=0){
                y->sign = -1;
            }
            return y;
        }
    }
    else if(i1->sign==-1 && i2->sign==-1){
        UnlimitedInt* p = new UnlimitedInt(i1->to_string()); p->sign=1;
        UnlimitedInt* q = new UnlimitedInt(i2->to_string()); q->sign=1;
        UnlimitedInt* x = div(p,q); 
        return x;
    }
}

UnlimitedInt* UnlimitedInt::mod(UnlimitedInt* i1, UnlimitedInt* i2){
    return sub(i1, mul(i2, div(i1,i2)));
}

