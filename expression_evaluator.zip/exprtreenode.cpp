/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "exprtreenode.h"

ExprTreeNode::ExprTreeNode(){
    type = ""; id = "";
    val = new UnlimitedRational();
    left = nullptr; right = nullptr; evaluated_value = nullptr;
}

ExprTreeNode::ExprTreeNode(string t, UnlimitedInt* v){
    type = t; id = "";
    if(type != "VAL"){
        val = new UnlimitedRational();
    }
    else{
        UnlimitedInt* a = new UnlimitedInt("1");
        val = new UnlimitedRational(v,a);
    }
    left = nullptr; right = nullptr; evaluated_value = nullptr;
}

ExprTreeNode::ExprTreeNode(string t, UnlimitedRational* v){
    type = t; id = "";
    if(type!="VAL"){
        val = new UnlimitedRational();
    }
    else{
        val = new UnlimitedRational(v->get_p(),v->get_q());
    }
    left = nullptr; right = nullptr; evaluated_value = nullptr;
}

ExprTreeNode::~ExprTreeNode(){
    delete val; val = nullptr;
    if(evaluated_value!=nullptr){
        delete evaluated_value; evaluated_value = nullptr;
    }
    type = "" ;id = "";
}
