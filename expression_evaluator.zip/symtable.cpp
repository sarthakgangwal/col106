/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"

SymbolTable::SymbolTable(){
    size = 0; root = nullptr;
}

void destr(SymEntry* root){
    if(root!=nullptr){
        destr(root->left);
        destr(root->right);
        delete root; root = nullptr;
    }
}

SymbolTable::~SymbolTable(){
    size = 0;
    destr(root);
}

int SymbolTable::get_size(){
    return size;
}

SymEntry* SymbolTable::get_root(){
    return root;
}

UnlimitedRational* SymbolTable::search(string k){
    SymEntry* curr = root;
    while(curr->key!=k){
        if(curr->key > k){
            curr = curr->left;
        }
        else{
            curr = curr->right;
        }
    }
    UnlimitedRational* ans = new UnlimitedRational(curr->val->get_p(),curr->val->get_q());
    return ans;
}

void SymbolTable::insert(string k, UnlimitedRational* v){
    if(root==nullptr){
        root = new SymEntry(k,v);
        return;
    }
    SymEntry* curr = root;
    while(curr->key != k){
        if(k > curr->key){
            if(curr->right==nullptr){
                curr->right = new SymEntry(k,v);
                break;
            }
            curr = curr->right;
        }
        else if(k < curr->key){
            if(curr->left==nullptr){
                curr->left = new SymEntry(k,v);
                break;
            }
            curr = curr->left;
        }
    }
    size++;
}

void mydel(SymEntry* root, string k, int &x){
    SymEntry* curr = root;
    while(curr->key != k){
        if(k > curr->key){
            curr = curr->right;
        }
        else if(k < curr->key){
            curr = curr->left;
        }

        if(curr == nullptr){
            break;
        }
    }

    if(curr==nullptr){return;}

    if(curr->left==nullptr && curr->right==nullptr){
        delete curr; x=1;
    }
    else if(curr->left==nullptr){
        SymEntry* temp = curr->right;
        curr->key=temp->key; curr->val=temp->val; curr->left=temp->left; curr->right=temp->right;
        temp = nullptr; x=1;
    }
    else if(curr->right==nullptr){
        SymEntry* temp = curr->left;
        curr->key=temp->key; curr->val=temp->val; curr->left=temp->left; curr->right=temp->right;
        temp = nullptr; x=1;
    }
    else{
        SymEntry* temp = curr->right;
        SymEntry* temp2 = curr->right;
        while(temp->left!=nullptr){
            temp=temp->left;
        }
        curr->key = temp->key; curr->val = temp->val;
        mydel(temp2, temp->key, x);
    }
}

void SymbolTable::remove(string k){
    int x=0;
    mydel(root,k,x);
    if(x==1){size--;}
}