/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedrational.h"

UnlimitedInt* gcd(UnlimitedInt* p, UnlimitedInt* q){
    UnlimitedInt* a = new UnlimitedInt(p->to_string());
    UnlimitedInt* b = new UnlimitedInt(q->to_string());
   
    while( a->to_string()!="0" && b->to_string()!="0"){
        if(a->get_size() > b->get_size()){
            UnlimitedInt* c = new UnlimitedInt(a->to_string());
            UnlimitedInt* d = new UnlimitedInt(b->to_string());
            a = d; b = UnlimitedInt::mod(c,d);
        }
        else if(a->get_size() < b->get_size()){
            UnlimitedInt* c = new UnlimitedInt(a->to_string());
            UnlimitedInt* d = new UnlimitedInt(b->to_string());
            b = c; a = UnlimitedInt::mod(d,c);
        }
        else{
            if(a->to_string() > b->to_string()){
                UnlimitedInt* c = new UnlimitedInt(a->to_string());
                UnlimitedInt* d = new UnlimitedInt(b->to_string());
                a = d; b = UnlimitedInt::mod(c,d);
            }
            else if(a->to_string() < b->to_string()){
                UnlimitedInt* c = new UnlimitedInt(a->to_string());
                UnlimitedInt* d = new UnlimitedInt(b->to_string());
                b = c; a = UnlimitedInt::mod(d,c);
            }
            else{
                break;
            }
        }
    }

    if(a->to_string()!="0"){
        return a;
    }
    else{
        return b;
    }
}

UnlimitedInt* UnlimitedRational::get_p(){
    return p;
}

UnlimitedInt* UnlimitedRational::get_q(){
    return q;
}

string UnlimitedRational::get_p_str(){
    return p->to_string();
}

string UnlimitedRational::get_q_str(){
    return q->to_string();
}

string UnlimitedRational::get_frac_str(){
    if(p->get_sign()==1 && q->get_sign()==1){
        return p->to_string()+"/"+q->to_string();
    }
    else if(p->get_sign()==-1 && q->get_sign()==1){
        return p->to_string()+"/"+q->to_string();
    }
    else if(p->get_sign()==1 && q->get_sign()==-1){
        UnlimitedInt* a = new UnlimitedInt("-1");
        UnlimitedInt* b = UnlimitedInt::mul(a,q);
        return "-"+p->to_string()+"/"+b->to_string();  
    }
    else if(p->get_sign()==-1 && q->get_sign()==-1){
        UnlimitedInt* a = new UnlimitedInt("-1");
        UnlimitedInt* b = UnlimitedInt::mul(a,p);
        UnlimitedInt* c = UnlimitedInt::mul(a,q);
        return b->to_string()+"/"+c->to_string();
    }
    else if(p->get_sign()==0 && q->get_sign()!=0){
        return "0/1";
    }
    else if(p->get_sign()==0 && q->get_sign()==0){
        return "0/0";
    }
    else if(p->get_sign()!=0 && q->get_sign()==0){
        return p->to_string()+"/"+"0";
    }
}

UnlimitedRational::UnlimitedRational(){
    p = new UnlimitedInt("1");
    q = new UnlimitedInt("1");
}

UnlimitedRational::UnlimitedRational(UnlimitedInt* num, UnlimitedInt* den){
    if(num->get_sign()==1 && den->get_sign()==1){
        UnlimitedInt* d = gcd(num,den);
        p = UnlimitedInt::div(num,d);
        q = UnlimitedInt::div(den,d);
    }
    else if(num->get_sign()==1 && den->get_sign()==-1){
        UnlimitedInt* a = new UnlimitedInt(den->to_string());
        UnlimitedInt* b = new UnlimitedInt("-1");
        UnlimitedInt* c = UnlimitedInt::mul(a,b);
        UnlimitedInt* d = gcd(num, c);
        q = UnlimitedInt::div(c,d);
        p = UnlimitedInt::mul(b, UnlimitedInt::div(num,d));
    }
    else if(num->get_sign()==-1 && den->get_sign()==1){
        UnlimitedInt* a = new UnlimitedInt(num->to_string());
        UnlimitedInt* b = new UnlimitedInt("-1");
        UnlimitedInt* c = UnlimitedInt::mul(a,b);
        UnlimitedInt* d = gcd(c, den);
        p = UnlimitedInt::div(num,d);
        q = UnlimitedInt::div(den,d);
    }
    else if(num->get_sign()==-1 && den->get_sign()==-1){
        UnlimitedInt* a = new UnlimitedInt(num->to_string());
        UnlimitedInt* b = new UnlimitedInt(den->to_string());
        UnlimitedInt* c = new UnlimitedInt("-1");
        UnlimitedInt* e = UnlimitedInt::mul(c,num);
        UnlimitedInt* f = UnlimitedInt::mul(c,den);
        UnlimitedInt* g = gcd(e,f);
        p = UnlimitedInt::div(e,g);
        q = UnlimitedInt::div(f,g);
    }
    else if(num->get_sign()==0 && den->get_sign()!=0){
        p = new UnlimitedInt("0");
        q = new UnlimitedInt("1");
    }
    else if(num->get_sign()==0 && den->get_sign()==0){
        p = new UnlimitedInt("0");
        q = new UnlimitedInt("0");
    }
    else if(num->get_sign()!=0 && den->get_sign()==0){
        p = new UnlimitedInt(num->to_string());
        q = new UnlimitedInt("0");
    }
}

UnlimitedRational::~UnlimitedRational(){
    delete p; delete q; p = nullptr; q = nullptr;
}

UnlimitedRational* UnlimitedRational::add(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* p = UnlimitedInt::add(UnlimitedInt::mul(p1,q2),UnlimitedInt::mul(p2,q1));
    UnlimitedInt* q = UnlimitedInt::mul(q1,q2);
    return new UnlimitedRational(p,q);
}

UnlimitedRational* UnlimitedRational::sub(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* p = UnlimitedInt::sub(UnlimitedInt::mul(p1,q2),UnlimitedInt::mul(p2,q1));
    UnlimitedInt* q = UnlimitedInt::mul(q1,q2);
    return new UnlimitedRational(p,q);
}

UnlimitedRational* UnlimitedRational::mul(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* p = UnlimitedInt::mul(p1,p2);
    UnlimitedInt* q = UnlimitedInt::mul(q1,q2);
    return new UnlimitedRational(p,q);
}

UnlimitedRational* UnlimitedRational::div(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* p = UnlimitedInt::mul(p1,q2);
    UnlimitedInt* q = UnlimitedInt::mul(p2,q1);
    return new UnlimitedRational(p,q);
}